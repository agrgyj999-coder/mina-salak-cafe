#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mina Salak Cafe — demo website
Run: python mina.py
Then open http://127.0.0.1:8000 in your browser.
Only uses Python's standard library.
"""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import socket
import os

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8000"))

HTML = r"""<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#20382d">
<title>مینا سالک | Mina Salak Café</title>
<style>
:root{--green:#20382d;--green2:#345542;--cream:#f7f0e4;--sand:#e8d7bb;--gold:#c69a55;--ink:#252821;--muted:#73766d;--white:#fffdf8}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--cream);color:var(--ink);font-family:Tahoma,"Segoe UI",sans-serif;line-height:1.8}
a{color:inherit;text-decoration:none}.topbar{background:var(--green);color:#f9f2e7;padding:10px 5%;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;font-size:13px}
header{padding:18px 5%;display:flex;align-items:center;justify-content:space-between;gap:20px;background:var(--white);position:sticky;top:0;z-index:5;box-shadow:0 4px 20px #1b2c2010}
.brand{display:flex;align-items:center;gap:12px}.logo{width:48px;height:48px;border-radius:50%;display:grid;place-items:center;background:var(--green);color:var(--gold);font-size:25px;border:2px solid var(--gold)}
.brand strong{display:block;font-size:20px;color:var(--green)}.brand small{display:block;color:var(--muted);font-size:11px;letter-spacing:1px}
nav{display:flex;gap:22px;font-size:14px}nav a:hover{color:var(--gold)}.cart-btn,.btn{border:0;border-radius:30px;padding:11px 19px;background:var(--gold);color:#211d15;font-weight:bold;cursor:pointer;font-family:inherit}
.hero{min-height:470px;padding:65px 7%;display:grid;grid-template-columns:1.1fr .9fr;align-items:center;gap:35px;background:radial-gradient(circle at 78% 25%,#526c51 0,#2c4938 30%,#1d3328 70%);color:var(--white);overflow:hidden}
.eyebrow{color:#e2bd7b;font-size:13px;letter-spacing:1px}.hero h1{font-size:clamp(35px,5vw,61px);line-height:1.35;margin:12px 0}.hero h1 span{color:#e4bd78}.hero p{color:#e1e6dc;max-width:520px}.hero .btn{display:inline-block;margin-top:14px;padding:13px 25px}
.cup-art{width:min(330px,80%);aspect-ratio:1;border-radius:50%;margin:auto;display:grid;place-items:center;background:radial-gradient(circle,#e9d8b7 0 31%,#b78b55 32% 34%,#f0e3cc 35% 48%,#b18a58 49% 51%,#304b39 52%);box-shadow:0 25px 70px #0005;position:relative}
.cup-art:before{content:"";width:118px;height:118px;border:12px solid #faf0dc;border-radius:50%;background:radial-gradient(ellipse,#6a3c25 0 40%,#8d5a35 41% 65%,#4c2b1c 66%);box-shadow:0 8px 22px #0004}
.cup-art:after{content:"M";position:absolute;font-family:Georgia,serif;font-size:38px;color:#c69a55;bottom:21px;right:25px}
.section{padding:65px 6%}.section-head{text-align:center;margin-bottom:30px}.section-head small{color:#a67a3d}.section-head h2{font-size:31px;color:var(--green);margin:3px 0}.section-head p{color:var(--muted);margin:0}
.features{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:-1px;padding:25px 6%;background:#e9dfce}
.feature{text-align:center;padding:12px}.feature b{display:block;color:var(--green)}.feature span{font-size:13px;color:var(--muted)}
.menu-tabs{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin:25px 0}.tab{border:1px solid #d6c5a9;background:transparent;padding:9px 18px;border-radius:24px;cursor:pointer;font-family:inherit}.tab.active,.tab:hover{background:var(--green);color:white;border-color:var(--green)}
.menu-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;max-width:1150px;margin:auto}.item{background:var(--white);border:1px solid #eee2d0;border-radius:17px;overflow:hidden;transition:.2s}.item:hover{transform:translateY(-4px);box-shadow:0 15px 35px #293b2912}
.item-visual{height:135px;display:grid;place-items:center;font-size:57px;background:linear-gradient(135deg,#e6d5b8,#f8f0e3)}.item-body{padding:17px}.item h3{margin:0;color:var(--green);font-size:17px}.item p{font-size:12px;color:var(--muted);min-height:43px;margin:6px 0 12px}.item-foot{display:flex;align-items:center;justify-content:space-between;gap:8px}.price{font-weight:bold;color:#986c30;font-size:14px}.add{width:35px;height:35px;border:0;border-radius:50%;background:var(--green);color:white;font-size:22px;cursor:pointer}
.about{background:#e9dfce;display:grid;grid-template-columns:1fr 1fr;gap:45px;align-items:center}.about-card{padding:32px;background:var(--green);color:white;border-radius:20px;box-shadow:15px 15px 0 #d0b990}.about-card h3{color:#e5bd7a;font-size:24px;margin-top:0}.about-card p{color:#e1e5dc}
.contact-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.contact{background:var(--white);padding:22px;border-radius:15px;text-align:center;border:1px solid #eee2d0}.contact .icon{font-size:27px}.contact strong{display:block;color:var(--green)}.contact span{font-size:13px;color:var(--muted)}
footer{background:#17291f;color:#e8e4d9;padding:30px 6%;display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;font-size:13px}footer b{color:#e4bd78}
.cart-panel{position:fixed;left:18px;bottom:18px;background:var(--white);border:1px solid #ddcba9;box-shadow:0 10px 35px #0002;border-radius:15px;padding:14px 18px;z-index:10;max-width:300px;display:none}.cart-panel.show{display:block}.cart-panel strong{color:var(--green)}.cart-panel p{margin:4px 0;font-size:13px}.cart-panel button{margin-top:8px;border:0;border-radius:20px;background:var(--green);color:white;padding:8px 14px;cursor:pointer;font-family:inherit}
.notice{font-size:12px;color:var(--muted);text-align:center;margin-top:24px}
@media(max-width:800px){nav{display:none}.hero{grid-template-columns:1fr;text-align:center;padding:45px 6%}.hero p{margin:auto}.cup-art{width:210px;grid-row:1}.features{grid-template-columns:1fr}.menu-grid{grid-template-columns:repeat(2,1fr)}.about{grid-template-columns:1fr}.contact-grid{grid-template-columns:1fr}}
@media(max-width:480px){.menu-grid{grid-template-columns:1fr}.topbar{justify-content:center;text-align:center}.section{padding:45px 5%}.brand strong{font-size:17px}}
</style>
</head>
<body>
<div class="topbar"><span>☕ قهوه‌ی خوب، حالِ خوب</span><span>📍 سمنان | ساعت کاری نمونه: هر روز ۹ تا ۲۳</span></div>
<header>
  <a class="brand" href="#home"><div class="logo">م</div><div><strong>مینا سالک</strong><small>MINA SALAK CAFÉ</small></div></a>
  <nav><a href="#home">خانه</a><a href="#menu">منو</a><a href="#about">درباره کافه</a><a href="#contact">تماس با ما</a></nav>
  <button class="cart-btn" onclick="showCart()">سبد سفارش <span id="cartCount">۰</span></button>
</header>
<main>
<section class="hero" id="home">
  <div><div class="eyebrow">یک مکث دلچسب در روزمرگی</div><h1>به کافه‌ی <span>مینا سالک</span><br>خوش اومدی!</h1><p>عطر قهوه‌ی تازه، شیرینی‌های دوست‌داشتنی و لحظه‌هایی که دلت می‌خواهد طولانی‌تر شوند. جای همیشگی‌ات همین‌جاست.</p><a class="btn" href="#menu">دیدن منو ←</a></div>
  <div class="cup-art" aria-label="تصویر گرافیکی فنجان قهوه"></div>
</section>
<section class="features">
  <div class="feature">🌿<b>مواد اولیه باکیفیت</b><span>انتخاب‌شده برای طعمی به‌یادماندنی</span></div>
  <div class="feature">☕<b>قهوه با عشق</b><span>از اسپرسوی پرقدرت تا لاته‌ی لطیف</span></div>
  <div class="feature">🍰<b>شیرینی هر روز</b><span>یک همراه خوشمزه برای نوشیدنی شما</span></div>
</section>
<section class="section" id="menu">
  <div class="section-head"><small>منوی پیشنهادی</small><h2>یه چیزی خوشمزه انتخاب کن</h2><p>قیمت‌ها نمونه و قابل ویرایش هستند.</p></div>
  <div class="menu-tabs">
    <button class="tab active" data-cat="همه">همه</button><button class="tab" data-cat="قهوه گرم">قهوه گرم</button><button class="tab" data-cat="نوشیدنی سرد">نوشیدنی سرد</button><button class="tab" data-cat="چای و دمنوش">چای و دمنوش</button><button class="tab" data-cat="کیک و دسر">کیک و دسر</button>
  </div>
  <div class="menu-grid" id="menuGrid"></div>
  <div class="notice">این یک وب‌سایت آزمایشی است؛ منو، قیمت‌ها، ساعت کاری و اطلاعات تماس واقعی نیستند.</div>
</section>
<section class="section about" id="about">
  <div><small>داستان ما</small><h2 style="color:var(--green);font-size:32px">برای لحظه‌های ساده و قشنگ</h2><p>در مینا سالک، قرار است چند دقیقه از شلوغی روز فاصله بگیری، نوشیدنی مورد علاقه‌ات را برداری و از لحظه لذت ببری. چه برای یک قرار دوستانه آمده باشی، چه برای خلوتی کوتاه با خودت، خوشحالیم که اینجایی.</p><a href="#contact" class="btn">راه‌های ارتباطی</a></div>
  <div class="about-card"><h3>میز تو آماده‌ست!</h3><p>☕ قهوه‌ی روزت رو انتخاب کن.</p><p>🍰 یه شیرینی هم کنارش بردار.</p><p>💚 و باقی روز رو با حال بهتر ادامه بده.</p></div>
</section>
<section class="section" id="contact">
  <div class="section-head"><small>منتظرت هستیم</small><h2>با ما در ارتباط باش</h2><p>اطلاعات زیر برای نسخه‌ی آزمایشی است.</p></div>
  <div class="contact-grid">
    <div class="contact"><div class="icon">📍</div><strong>آدرس</strong><span>سمنان، ایران (آدرس دقیق ثبت نشده)</span></div>
    <div class="contact"><div class="icon">🕘</div><strong>ساعت کاری</strong><span>هر روز، ۹ صبح تا ۱۱ شب (نمونه)</span></div>
    <div class="contact"><div class="icon">📱</div><strong>سفارش و تماس</strong><span>شماره تماس هنوز ثبت نشده</span></div>
  </div>
</section>
</main>
<footer><div><b>مینا سالک | Mina Salak Café</b><br>یه فنجون آرامش، همین نزدیکی.</div><div>© <span id="year"></span> — نسخه‌ی آزمایشی</div></footer>
<div class="cart-panel" id="cartPanel"><strong>سبد سفارش آزمایشی</strong><p id="cartText">هنوز چیزی انتخاب نکردی.</p><button onclick="clearCart()">خالی کردن سبد</button></div>
<script>
const products=[
 {name:"اسپرسو",cat:"قهوه گرم",price:110000,icon:"☕",desc:"یک شات قهوه‌ی غلیظ و خوش‌عطر"},
 {name:"آمریکانو",cat:"قهوه گرم",price:145000,icon:"🖤",desc:"اسپرسو با آب داغ، ساده و دلنشین"},
 {name:"کاپوچینو",cat:"قهوه گرم",price:210000,icon:"☕",desc:"اسپرسو، شیر بخارداده و فوم لطیف"},
 {name:"لاته",cat:"قهوه گرم",price:220000,icon:"🥛",desc:"قهوه‌ی ملایم با شیر گرم"},
 {name:"هات چاکلت",cat:"قهوه گرم",price:220000,icon:"🍫",desc:"شکلات داغ و خامه‌ای"},
 {name:"آیس موکا",cat:"نوشیدنی سرد",price:270000,icon:"🧋",desc:"قهوه، شکلات و شیر خنک"},
 {name:"لیموناد",cat:"نوشیدنی سرد",price:160000,icon:"🍋",desc:"ترش و خنک برای روزهای گرم"},
 {name:"موهیتو",cat:"نوشیدنی سرد",price:180000,icon:"🌿",desc:"نعناع، لیمو و خنکی دلچسب"},
 {name:"چای ایرانی",cat:"چای و دمنوش",price:80000,icon:"🫖",desc:"چای خوش‌رنگ، مناسب گپ دوستانه"},
 {name:"دمنوش آرامش",cat:"چای و دمنوش",price:130000,icon:"🌼",desc:"ترکیبی گیاهی و خوش‌عطر"},
 {name:"چیزکیک",cat:"کیک و دسر",price:235000,icon:"🍰",desc:"برشی لطیف برای کنار قهوه"},
 {name:"کیک شکلاتی",cat:"کیک و دسر",price:200000,icon:"🍫",desc:"کیک شکلاتی نرم و خوشمزه"}
];
let cart=[];
const fa=n=>n.toLocaleString("fa-IR");
function render(cat="همه"){
 const list=cat==="همه"?products:products.filter(p=>p.cat===cat);
 document.getElementById("menuGrid").innerHTML=list.map(p=>`<article class="item"><div class="item-visual">${p.icon}</div><div class="item-body"><h3>${p.name}</h3><p>${p.desc}</p><div class="item-foot"><span class="price">${fa(p.price)} تومان</span><button class="add" aria-label="افزودن ${p.name}" onclick="addItem('${p.name}')">+</button></div></div></article>`).join("");
}
function addItem(name){cart.push(name);document.getElementById("cartCount").textContent=fa(cart.length);document.getElementById("cartText").textContent="انتخاب‌ها: "+cart.join("، ");document.getElementById("cartPanel").classList.add("show")}
function showCart(){document.getElementById("cartPanel").classList.toggle("show");document.getElementById("cartText").textContent=cart.length?"انتخاب‌ها: "+cart.join("، "):"هنوز چیزی انتخاب نکردی."}
function clearCart(){cart=[];document.getElementById("cartCount").textContent="۰";document.getElementById("cartText").textContent="هنوز چیزی انتخاب نکردی."}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");render(b.dataset.cat)}));
document.getElementById("year").textContent=new Date().getFullYear();render();
</script>
</body>
</html>"""

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/index.html"):
            body = HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/health":
            body = json.dumps({"status": "ok", "site": "Mina Salak Cafe"}, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404, "صفحه پیدا نشد")

    def log_message(self, fmt, *args):
        print("[mina] " + (fmt % args))

def get_lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "آی‌پی شبکه مشخص نشد"
    finally:
        s.close()

if __name__ == "__main__":
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print("=" * 52)
    print("Mina Salak Cafe is running!")
    print("روی همین دستگاه باز کن: http://127.0.0.1:%s" % PORT)
    print("در دستگاه دیگر روی همان Wi-Fi: http://%s:%s" % (get_lan_ip(), PORT))
    print("برای توقف: Ctrl+C")
    print("=" * 52)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nسرور متوقف شد.")
        server.server_close()
